import { Elysia } from "elysia";
import { jwt } from "@elysiajs/jwt";
import { cors } from "@elysiajs/cors";
import { staticPlugin } from "@elysiajs/static";
import { config } from "./config";
import { getDb } from "./db/connection";
import { logger, requestHooks } from "./logger";
import {
  authPlugin,
  providersPlugin,
  modelsPlugin,
  keysPlugin,
  settingsPlugin,
  proxyPlugin,
  statsPlugin,
  codexPlugin,
  codexPublicPlugin,
  antigravityPublicPlugin,
  antigravityUsagePlugin,
  freebuffUsagePlugin,
  requestLogsPlugin,
  rtkPlugin,
} from "./api";
import { initRtkOnStartup, rtkPublicPlugin } from "./plugins/rtk";
import { cavemanPublicPlugin, cavemanPlugin } from "./plugins/caveman";
import { customSkillsPlugin } from "./plugins/custom-skills";

// Initialize database
getDb();

// Auto-start RTK if enabled in settings
initRtkOnStartup();

const app = new Elysia()
  .onRequest(requestHooks.onRequest)
  .onBeforeHandle(({ request, set }) => {
    const pathname = new URL(request.url).pathname;
    if (
      /(^|\/)\.(?:env(?:\..*)?|git)(?:\/|$)/i.test(pathname) ||
      /(^|\/)data(?:\/|$)/i.test(pathname) ||
      /\.(?:db|sqlite|sqlite3|db-wal|db-shm)$/i.test(pathname)
    ) {
      set.status = 404;
      return new Response("Not Found", { status: 404 });
    }
  })
  .onAfterHandle(requestHooks.onAfterHandle)
  .onError(requestHooks.onError)
  .use(cors())
  .get("/api", () => ({
    name: "KloveRouter API",
    status: "ok",
  }))
  .use(
    jwt({
      secret: config.jwtSecret,
      name: "jwt",
    }),
  )
  // Public routes
  .use(authPlugin)
  .use(codexPublicPlugin)
  .use(antigravityPublicPlugin)
  .use(proxyPlugin);

// RTK public routes
app.use(rtkPublicPlugin);

// Caveman public routes
app.use(cavemanPublicPlugin);

// Protected routes (require JWT)
const protectedApp = new Elysia()
  .guard({
    async beforeHandle({ jwt, headers, set }: any) {
      const auth = headers.authorization;
      if (!auth || !auth.startsWith("Bearer ")) {
        set.status = 401;
        return { error: "Unauthorized", message: "Missing or invalid token" };
      }
      const payload = await jwt.verify(auth.slice(7));
      if (!payload) {
        set.status = 401;
        return {
          error: "Unauthorized",
          message: "Invalid or expired token",
        };
      }
    },
  })
  .use(providersPlugin)
  .use(modelsPlugin)
  .use(keysPlugin)
  .use(settingsPlugin)
  .use(statsPlugin)
  .use(requestLogsPlugin)
  .use(antigravityUsagePlugin)
  .use(freebuffUsagePlugin)
  .use(codexPlugin)
  .use(rtkPlugin)
  .use(cavemanPlugin)
  .use(customSkillsPlugin);

app.use(protectedApp as any);

// OAuth callback listener is reachable on all network interfaces.
new Elysia()
  .use(codexPublicPlugin)
  .use(antigravityPublicPlugin)
  .listen({ port: 1455, hostname: "0.0.0.0" });

// Serve frontend in production
if (!config.isDev) {
  // First try static files
  app.use(
    staticPlugin({
      assets: "./web/dist",
      prefix: "/",
    }),
  );

  // Catch-all: serve index.html for SPA routing
  const indexPath = Bun.file("./web/dist/index.html");
  if (await indexPath.exists()) {
    app.get(
      "/*",
      () =>
        new Response(indexPath, {
          headers: { "Content-Type": "text/html" },
        }),
    );
  }
}

app.listen({ port: config.port, hostname: "0.0.0.0", idleTimeout: 300 });

const b = "\x1b[1m",
  r = "\x1b[0m";
const blue = "\x1b[38;2;91;206;250m",
  pink = "\x1b[38;2;245;169;184m",
  white = "\x1b[97m",
  dim = "\x1b[2m";
const green = "\x1b[38;2;80;200;120m",
  cyan = "\x1b[38;2;0;200;200m",
  yellow = "\x1b[38;2;255;200;50m";
const bgBlue = "\x1b[48;2;91;206;250m",
  bgGreen = "\x1b[48;2;80;200;120m";

function badge(text: string, color: string) {
  return `${color}${white}${b} ${text} ${r}`;
}

const ascii = `
${b}${blue}     __ __ __${r}
${b}${pink}    / //_// /___ _   _____${r}
${b}${white}   / ,<  / / __ \\ | / / _ \\${r}
${b}${pink}  / /| |/ / /_/ / |/ /  __/${r}
${b}${blue} /_/ |_/_/\\____/|___/\\___/${r}
`;
const version = "1.0.0";

logger.badge(
  "KLOVE",
  `v${version} · https://github.com/SterTheStar/KloveRouter`,
);
logger.success("Server running", {
  panel: `http://0.0.0.0:${config.port}`,
  api: `http://0.0.0.0:${config.port}/api`,
  chat_completions: `http://0.0.0.0:${config.port}/v1/chat/completions`,
  responses_api: `http://0.0.0.0:${config.port}/v1/responses`,
});
logger.info("Codex callback listener", {
  address: "http://0.0.0.0:1455/auth/callback",
});
