import { describe, expect, test } from "bun:test";
import {
  codexModels,
  codexRequestBody,
  codexStreamToOpenAI,
} from "./codex.client";

const encoder = new TextEncoder();

function upstream(chunks: string[]) {
  return new Response(
    new ReadableStream({
      async start(controller) {
        for (const chunk of chunks) {
          controller.enqueue(encoder.encode(chunk));
        }
        controller.close();
      },
    }),
  );
}

describe("codexStreamToOpenAI", () => {
  test("forwards a delta before the upstream stream completes", async () => {
    let releaseUpstream!: () => void;
    const blocked = new Promise<void>((resolve) => {
      releaseUpstream = resolve;
    });
    const source = new Response(
      new ReadableStream({
        async start(controller) {
          controller.enqueue(
            encoder.encode(
              'data: {"type":"response.output_text.delta","delta":"first"}\n\n',
            ),
          );
          await blocked;
          controller.enqueue(
            encoder.encode(
              'data: {"type":"response.output_text.delta","delta":"second"}\n\n',
            ),
          );
          controller.close();
        },
      }),
    );
    const response = codexStreamToOpenAI(source, "gpt-test");
    const reader = response.body!.getReader();
    const first = await reader.read();

    expect(new TextDecoder().decode(first.value)).toContain(
      '"content":"first"',
    );
    releaseUpstream();
    while (!(await reader.read()).done) {
      /* Drain the remaining stream. */
    }
  });

  test("parses CRLF events split across transport chunks", async () => {
    let releaseUpstream!: () => void;
    const blocked = new Promise<void>((resolve) => {
      releaseUpstream = resolve;
    });
    const source = new Response(
      new ReadableStream({
        async start(controller) {
          controller.enqueue(
            encoder.encode(
              'data: {"type":"response.output_text.delta","delta":"hello"}\r\n',
            ),
          );
          controller.enqueue(encoder.encode("\r\n"));
          await blocked;
          controller.close();
        },
      }),
    );
    const reader = codexStreamToOpenAI(source, "gpt-test").body!.getReader();
    const first = await reader.read();

    expect(new TextDecoder().decode(first.value)).toContain(
      '"content":"hello"',
    );
    releaseUpstream();
    while (!(await reader.read()).done) {
      /* Drain the remaining stream. */
    }
  });

  test("does not enqueue or close after the client cancels", async () => {
    let releaseUpstream!: () => void;
    const blocked = new Promise<void>((resolve) => {
      releaseUpstream = resolve;
    });
    const source = new Response(
      new ReadableStream({
        async start(controller) {
          controller.enqueue(
            encoder.encode(
              'data: {"type":"response.output_text.delta","delta":"partial"}\n\n',
            ),
          );
          await blocked;
          controller.close();
        },
      }),
    );
    const reader = codexStreamToOpenAI(source, "gpt-test").body!.getReader();

    await reader.read();
    await reader.cancel();
    releaseUpstream();
    await new Promise((resolve) => setTimeout(resolve, 0));
  });

  test("processes a final event without a trailing separator", async () => {
    const response = codexStreamToOpenAI(
      upstream(['data: {"type":"response.output_text.delta","delta":"last"}']),
      "gpt-test",
    );

    expect(await response.text()).toContain('"content":"last"');
  });
});

describe("codexModels", () => {
  test("uses the selected SQLite credential instead of the legacy session", async () => {
    const originalFetch = globalThis.fetch;
    let authorization = "";
    let accountId = "";
    globalThis.fetch = (async (
      _input: RequestInfo | URL,
      init?: RequestInit,
    ) => {
      const headers = new Headers(init?.headers);
      authorization = headers.get("authorization") ?? "";
      accountId = headers.get("chatgpt-account-id") ?? "";
      return Response.json({
        models: [{ slug: "gpt-test", display_name: "GPT Test" }],
      });
    }) as typeof fetch;

    try {
      const models = await codexModels({
        access_token: "sqlite-token",
        account_id: "sqlite-account",
      });
      expect(authorization).toBe("Bearer sqlite-token");
      expect(accountId).toBe("sqlite-account");
      expect(models[0]?.id).toBe("gpt-test");
    } finally {
      globalThis.fetch = originalFetch;
    }
  });
});

describe("codexRequestBody", () => {
  test("omits empty or disabled reasoning and does not send output token limits", () => {
    expect(
      codexRequestBody({ messages: [], max_tokens: 20 }, "gpt-test"),
    ).not.toHaveProperty("max_output_tokens");
    expect(
      codexRequestBody({ messages: [], max_tokens: 20 }, "gpt-test"),
    ).not.toHaveProperty("reasoning");
    const disabled = { messages: [] } as any;
    Object.defineProperty(disabled, "__klove_reasoning", {
      value: { effort: "none", upstreamValue: "none" },
    });
    expect(codexRequestBody(disabled, "gpt-test")).not.toHaveProperty(
      "reasoning",
    );
  });
});
